<?php
include_once ("z_db.php");
// Inialize session
session_start();
// Check, if username session is NOT set then this page will jump to login page
if (!isset($_SESSION['username'])) {
        print "
				<script language='javascript'>
					window.location = 'index.php';
				</script>
			";
}
?>
<!DOCTYPE html>
<html lang="en" class="app">
<head>
<meta charset="utf-8" />
<title>Downline</title>
<meta name="description" content="app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<link rel="stylesheet" href="css/app.v1.css" type="text/css" />
<!--[if lt IE 9]> <script src="js/ie/html5shiv.js"></script> <script src="js/ie/respond.min.js"></script> <script src="js/ie/excanvas.js"></script> <![endif]-->
<div id="google_translate_element" align="right"></div><script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE, multilanguagePage: true}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

</head>
<style>
body {
  overflow-y: scroll ! important;
}
</style>
<body class="">
<section class="vbox">
  <header class="bg-primary header header-md navbar navbar-fixed-top-xs box-shadow">
    <div class="navbar-header aside-md dk"> <a class="btn btn-link visible-xs" data-toggle="class:nav-off-screen" data-target="#nav"> <i class="fa fa-bars"></i> </a> <a href="dashboard.php" class="navbar-brand"><img src="images/logo.png" class="m-r-sm"><?php $query="SELECT header from settings where sno=0";


 $result = mysqli_query($con,$query);

while($row = mysqli_fetch_array($result))
{
	$header="$row[header]";
	print $header;
	}
  ?></a> <a class="btn btn-link visible-xs" data-toggle="dropdown" data-target=".user"> <i class="fa fa-cog"></i> </a> </div>


    <ul class="nav navbar-nav navbar-right m-n hidden-xs nav-user user">

      <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <span class="thumb-sm avatar pull-left"> <img src="images/a0.jpg"> </span> <?php
		  $sql="SELECT fname FROM  affiliateuser WHERE username='".$_SESSION['username']."'";
		  if ($result = mysqli_query($con, $sql)) {

    /* fetch associative array */
    while ($row = mysqli_fetch_row($result)) {
        print $row[0];
    }

}



	   ?> <b class="caret"></b> </a>
        <ul class="dropdown-menu animated fadeInRight">
          <span class="arrow top"></span>

          <li> <a href="profile.php">Profile</a> </li>
     <!--<li> <a href="notifications.php"> Notifications </a> </li>
                    <li> <a href="contact.php">Help</a> </li>
                    <li class="divider"></li>-->
          <li class="divider"></li>
          <li> <a href="logout.php" data-toggle="ajaxModal" >Logout</a> </li>
        </ul>
      </li>
    </ul>
  </header>
  <section>
    <section class="hbox stretch">
      <!-- .aside -->
      <aside class="bg-light aside-md hidden-print" id="nav">
        <section class="vbox">
          <section class="w-f scrollable">
            <div class="slim-scroll" data-height="auto" data-disable-fade-out="true" data-distance="0" data-size="10px" data-color="#333333">
              <div class="clearfix wrapper dk nav-user hidden-xs">
                <div class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <span class="thumb avatar pull-left m-r"> <img src="images/a0.jpg"> <i class="on md b-black"></i> </span> <span class="hidden-nav-xs clear"> <span class="block m-t-xs"> <strong class="font-bold text-lt"><?php
		  $sql="SELECT fname,country,pcktaken FROM  affiliateuser WHERE username='".$_SESSION['username']."'";
		  if ($result = mysqli_query($con, $sql)) {

    /* fetch associative array */
    while ($row = mysqli_fetch_row($result)) {
        print $row[0];
		$coun=$row[1];
		$pcktaken=$row[2];
		 $sql2="SELECT name FROM packages WHERE id=$pcktaken";
		 if ($result2 = mysqli_query($con, $sql2)) {
		  while ($row2 = mysqli_fetch_row($result2)) {

		 $pkname=$row2[0];
		 }
		 }

    }

}



	   ?></strong> <b class="caret"></b> </span> <span class="text-muted text-xs block"></span> </span> </a>
                  <ul class="dropdown-menu animated fadeInRight m-t-xs">
                    <span class="arrow top hidden-nav-xs"></span>

                    <li> <a href="profile.php">Profile</a> </li>
                   <!--<li> <a href="notifications.php"> Notifications </a> </li>
                    <li> <a href="contact.php">Help</a> </li>
                    <li class="divider"></li>-->
                    <li> <a href="logout.php" data-toggle="ajaxModal" >Logout</a> </li>
                  </ul>
                </div>
              </div>
              <!-- nav -->
              <nav class="nav-primary hidden-xs">
                <div class="text-muted text-sm hidden-nav-xs padder m-t-sm m-b-sm">Start</div>
                <ul class="nav nav-main" data-ride="collapse">
                  <li> <a href="paymentshistory.php" class="auto"> <i class="i i-statistics icon"> </i> <span class="font-bold">All College</span> </a> </li>
				  <li> <a href="uploadpp.php" class="auto"> <i class="i i-statistics icon"> </i> <span class="font-bold">Upload PPT</span> </a> </li>
				  <li> <a href="shareppt.php" class="auto"> <i class="i i-statistics icon"> </i> <span class="font-bold">Share PPT</span> </a> </li>
                  <li> <a href="newppt.php" class="auto"> <i class="i i-statistics icon"> </i> <span class="font-bold">New PPT</span> </a> </li>
                  <!--<li class="active" > <a href="#" class="auto"> <span class="pull-right text-muted"> <i class="i i-circle-sm-o text"></i> <i class="i i-circle-sm text-active"></i> </span> <i class="i i-lab icon"> </i> <span class="font-bold">Account</span> </a>
                    <ul class="nav dk">
                      <li  > <a href="downline.php" class="auto"> <i class="i i-dot"></i> <span>Downline/Earnings</span> </a> </li>



                      <li> <a href="invoice.php" class="auto"> <i class="i i-dot"></i> <span>Invoice/Account Status</span> </a> </li>
                      <li class="active"> <a href="paymentshistory.php" class="auto"> <i class="i i-dot"></i> <span>Payments History</span> </a> </li>
                    </ul>
                  </li>

                  <li > <a href="#" class="auto"> <span class="pull-right text-muted"> <i class="i i-circle-sm-o text"></i> <i class="i i-circle-sm text-active"></i> </span> <i class="i i-grid2 icon"> </i> <span class="font-bold">Help</span> </a>
                    <ul class="nav dk">
                      <li > <a href="notifications.php" class="auto"> <b class="badge bg-success lt pull-right">2</b> <i class="i i-dot"></i> <span>Notifications</span> </a> </li>
                      <li > <a href="contact.php" class="auto"> <i class="i i-dot"></i> <span>Contact</span> </a> </li>
                    </ul>
                  </li>-->
                </ul>
                  </li>
                </ul>
                <div class="line dk hidden-nav-xs"></div>


              </nav>
              <!-- / nav -->
            </div>
          </section>
          <footer class="footer hidden-xs no-padder text-center-nav-xs"> <a href="logout.php" data-toggle="ajaxModal" class="btn btn-icon icon-muted btn-inactive pull-right m-l-xs m-r-xs hidden-nav-xs"> <i class="i i-logout"></i> </a> <a href="#nav" data-toggle="class:nav-xs" class="btn btn-icon icon-muted btn-inactive m-l-xs m-r-xs"> <i class="i i-circleleft text"></i> <i class="i i-circleright text-active"></i> </a> </footer>
        </section>
      </aside>
      <!-- /.aside -->
      <section id="content">
        <section class="vbox">
          <header class="header bg-white b-b b-light">
            <p><strong>PPT History | </strong> </p>
          </header>


		  <section class="scrollable wrapper">
		  <?php if($_SERVER['REQUEST_METHOD'] == 'POST')
{

$pptname=mysqli_real_escape_string($con,$_POST['pptname']);
$from=$_SESSION['username'];
//$query=mysqli_query($con,"INSERT INTO `shareppt` ( `from`, `code`, `pptname`, `to`, `dt`) VALUES ('7520536026', '', '', '', '')");
$dt=date('d-m-y');
foreach($_POST['id'] as $item){
	//echo $item;
	$query=mysqli_query($con,"INSERT INTO `shareppt` ( `userfrom`, `code`, `pptname`, `userto`, `dt`) VALUES ('$from', '', '$pptname', '$item', '$dt')");

}}





      ?>

            <div class="row">

              <div class="col-sm-12 portlet">
                <section class="panel panel-success portlet-item">
                  <header class="panel-heading"> Your All PPT List </header>
                  <div class="table-responsive">
				  <form action="#" method="post" >
                <div class="form-group">


						  				  <?php $ppque="SELECT * FROM ppt where username='".$_SESSION['username']."' ORDER BY id DESC";
										$ppdt = mysqli_query($con,$ppque);
?>

                          <select data-required="true" class="form-control m-t" name="pptname" required>
                                <option value="">Please choose PPT</option>
                                <?php
while($rowpp = mysqli_fetch_array($ppdt))
{ ?>
<option value="<?php echo $rowpp['ppt'];?>"><?php echo $rowpp['ppt_name'];?></option>

<?php }?>
</select>
                        </div>

	 <input type="text" value="<?php echo 'College Name';?>" style="color: #000;font-weight: 700;width: 152px;">
	 <input type="text" value="<?php echo 'Code';?>" style="color: #000;font-weight: 700;width: 152px;">
	 <input type="text" value="<?php echo 'country';?>" style="color: #000;font-weight: 700;width: 152px;">
	 <input type="text" value="<?php echo 'Address';?>" style="color: #000;font-weight: 700;width: 152px;">
	 <input type="text" value="<?php echo 'Select';?>" style="color: #000;font-weight: 700;width: 152px;">
	 <br>

				  <?php $query="SELECT * FROM  affiliateuser ORDER BY id DESC";


 $result = mysqli_query($con,$query);
$i=1;
while($row = mysqli_fetch_array($result))
{ ?>


	<input type="text" value="<?php echo $row['college_name'];?>">
	 <input type="text" value="<?php echo $row['code'];?>">
	 <input type="text" value="<?php echo $row['country'];?>">
	 <input type="text" value="<?php echo $row['address'];?>">
	 <input type="checkbox" name="id[]" value="<?php echo $row['username'];?>"><br>


<?php }?><br>

                  <button type="submit" style="
    width: 163px;
    BACKGROUND-COLOR: #177bbb;
    color: #fff!important;
" class="btn btn-sm btn-default">Submit</button>
                    </form>
              </div>
        <div class="table-responsive">
                <table class="table table-striped b-t b-light">
                  <thead>
                    <tr>

                      <th width="5%">S.No</th>
					  <th width="20%">College Name</th>
                      <th width="10%">PPT Name</th>
					  <th width="10%">Date</th>






                    </tr>
                  </thead>
                  <tbody>
				  <?php $query1="SELECT * FROM  shareppt where userfrom ='".$_SESSION['username']."' ORDER BY id DESC";


 $result1 = mysqli_query($con,$query1);
$i=0;
while($row1 = mysqli_fetch_array($result1))
{

	$id=$i++;
	$dt="$row1[dt]";
	$ppname="$row1[pptname]";
	$to="$row1[userto]";


  print "<tr>

				  <td>
				  $id
				  </td>
				  <td>
				  $to
				  </td>
				  <td>
				  <a href='images/$ppname'>$ppname </a>
				  </td>
<td>
				  $dt
				  </td>
				  </tr>";

  }
  ?>

                  </tbody>
                </table>
              </div>
                </section>

              </div>
            </div>
          </section>
        </section>
        <a href="#" class="hide nav-off-screen-block" data-toggle="class:nav-off-screen" data-target="#nav"></a> </section>
    </section>
  </section>
</section>
<!-- Bootstrap -->
<!-- App -->
<script src="js/app.v1.js"></script>
<script src="js/jquery.ui.touch-punch.min.js"></script>
<script src="js/jquery-ui-1.10.3.custom.min.js"></script>
<script src="js/app.plugin.js"></script>
</body>
</html>